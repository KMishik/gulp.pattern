Before using this lessons you have to run 'npm install' for auto installing 
all dependecies from 'package.json'

